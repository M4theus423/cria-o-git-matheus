quero aprender a fazer programação de aplicativos
vou me esforçar para tentar acompanhar o conteúdo 